"""
ErnestOS — explicit data migrations.

Schema columns are added automatically by `db.init_db()`. This module is for
*data* changes that must be applied deliberately, once, against a live
database — never on import and never on boot.

Each migration is:
  * numbered, so the order is fixed;
  * idempotent, so running it twice changes nothing;
  * non-destructive, so user history survives.

Run them all:

    python migrations.py

Run one:

    python migrations.py 0001
"""

from __future__ import annotations

import logging
import sys

import db
from db import SessionLocal

log = logging.getLogger("ernestos.migrations")


def m0001_retire_summary_habit() -> dict:
    """Superseded by `0006`. Kept as a no-op so the numbering stays honest.

    This migration used to archive the journal habit, on the reasoning that a
    journal is a status rather than a habit. That product decision was reversed:
    writing the day up is one of the non-negotiables again, and `0006` restores
    the habit and backfills it from the journal entries.

    It must not run any more. Left as a live step it would re-archive the habit
    every time the chain was replayed, immediately undoing `0006` — the two
    would fight, and which one won would depend on the order they happened to
    be invoked in.
    """
    return {"migration": "0001_retire_summary_habit",
            "status": "superseded by 0006", "archived": 0}


#: Where migration 0002 parks the goals table. Keeping the name in one place
#: means the rollback instruction and the code cannot disagree.
GOALS_ARCHIVE_TABLE = "goals_archived_v1"


def m0002_retire_goals() -> dict:
    """Take Goals out of the live schema without destroying the rows.

    Goals are gone from the product: no bot menu, no Mini App screen, no API,
    no model. What is left is the `goals` table on databases that already have
    one, still holding whatever users wrote there.

    Dropping it would be the tidy move and the wrong one — a deleted table is
    not recoverable from a running system, and "we removed a screen" must
    never mean "we deleted your data". So the table is *renamed* instead:

      * the rows survive, with their workspace_id intact;
      * nothing in the application can reach them, which is the actual goal;
      * `Base.metadata.create_all()` will not recreate `goals`, because the
        model no longer exists;
      * the change is undone with one statement.

    Rollback:

        ALTER TABLE goals_archived_v1 RENAME TO goals;

    then restore the Goal model and its routes from version control.
    """
    from sqlalchemy import inspect, text

    inspector = inspect(db.engine)
    tables = set(inspector.get_table_names())

    if "goals" not in tables:
        # Either a fresh database or a second run.
        return {"migration": "0002_retire_goals",
                "status": "already archived" if GOALS_ARCHIVE_TABLE in tables
                          else "nothing to do",
                "rows": 0}

    if GOALS_ARCHIVE_TABLE in tables:
        # An archive already exists from an earlier run and a `goals` table
        # came back. Refuse rather than overwrite the older archive.
        raise SystemExit(
            f"both goals and {GOALS_ARCHIVE_TABLE} exist — resolve by hand "
            f"before re-running 0002")

    with db.engine.begin() as conn:
        rows = conn.execute(text("SELECT count(*) FROM goals")).scalar() or 0
        conn.execute(text(f"ALTER TABLE goals RENAME TO {GOALS_ARCHIVE_TABLE}"))

    return {"migration": "0002_retire_goals", "status": "archived",
            "rows": rows, "archive": GOALS_ARCHIVE_TABLE}


#: What each retired theme is replaced by. The mapping is by intent, not by
#: hue: someone who chose `rose` wanted pink and someone who chose `obsidian`
#: wanted something restrained, so each lands on the closest survivor rather
#: than all of them being flattened into the default.
#:
#: `aurora` is deliberately absent. The name was reused for the new violet
#: theme, so those rows are already valid and must be left untouched.
#:
#: `ocean` was removed from this mapping when the palette was rebuilt: it used
#: to be a retired name pointing at `cobalt`, and it is now the *default* theme.
#: Leaving it here would mean running 0003 after 0005 quietly moved every
#: default account onto a name that no longer exists. Ancient rows still holding
#: `ocean` are simply valid again, which is the outcome that needed no code.
RETIRED_THEMES = {
    "obsidian": "slate",
    "emerald": "slate",
    "rose": "blossom",
    "pink": "blossom",
}


def m0003_retire_themes() -> dict:
    """Move accounts off the themes the Mini App no longer styles.

    The palette shrank from nine themes to four. A row still holding a retired
    name is not broken — the app reads any unknown value as the default — but
    the stored value and the Settings screen would disagree until the user
    picked something, so the value is rewritten once here.

    Only the known retired names are touched. A row already on one of the four
    is left alone, which is what makes a second run a no-op.
    """
    from sqlalchemy import update

    from db import User

    moved: dict[str, int] = {}
    with SessionLocal() as s:
        for old, new in RETIRED_THEMES.items():
            count = s.execute(
                update(User).where(User.theme == old).values(theme=new)).rowcount
            if count:
                moved[f"{old}→{new}"] = count
        s.commit()
    return {"migration": "0003_retire_themes", "moved": moved,
            "total": sum(moved.values())}


def m0004_recompute_prayer_completion() -> dict:
    """Re-derive the `5x namoz` habit from what was actually prayed.

    The habit used to be marked done whenever the day's *quality* score
    reached 2.5, which meant three prayers could complete a habit called "5x
    namoz". Completion is now all five prayed (or an excused day), and those
    are two separate questions — see `services.prayer_is_complete`.

    Every existing HabitLog row for that habit was written under the old rule,
    so this recomputes them from the PrayerLog rows, which are the source of
    truth and are not touched. Days where the answer does not change are left
    alone, which is what makes a second run a no-op.

    This does move historical numbers: a day with three prayers logged stops
    counting as a completed habit. That is the point — the old number was
    wrong, and leaving it in place would mean the streak and the statistics
    keep reporting something the user did not do.
    """
    from sqlalchemy import select as sql_select

    from db import Habit, HabitLog, PrayerDay, PrayerLog, User, Workspace
    import services as svc

    changed = corrected_true = corrected_false = 0

    with SessionLocal() as s:
        habits = s.scalars(sql_select(Habit).where(
            Habit.system_key == svc.SYSTEM_PRAYER)).all()

        for habit in habits:
            workspace = s.get(Workspace, habit.workspace_id)
            gender = None
            if workspace is not None:
                owner = s.get(User, workspace.user_id)
                gender = owner.gender if owner else None

            # Every day this workspace has either a prayer record or a habit
            # log for: both sides have to be reconciled, because a log may
            # exist for a day whose prayers were later cleared.
            days = set(s.scalars(sql_select(PrayerLog.day).where(
                PrayerLog.workspace_id == habit.workspace_id)).all())
            days |= set(s.scalars(sql_select(HabitLog.day).where(
                HabitLog.workspace_id == habit.workspace_id,
                HabitLog.habit_id == habit.id)).all())

            for day in days:
                statuses = {r.prayer: r.status for r in s.scalars(
                    sql_select(PrayerLog).where(
                        PrayerLog.workspace_id == habit.workspace_id,
                        PrayerLog.day == day)).all()}
                state = s.scalar(sql_select(PrayerDay).where(
                    PrayerDay.workspace_id == habit.workspace_id,
                    PrayerDay.day == day))
                excused = bool(state and state.excused)
                should = svc.prayer_is_complete(statuses, gender, excused)

                row = s.scalar(sql_select(HabitLog).where(
                    HabitLog.workspace_id == habit.workspace_id,
                    HabitLog.habit_id == habit.id, HabitLog.day == day))
                if row is None:
                    if not should:
                        continue
                    s.add(HabitLog(workspace_id=habit.workspace_id,
                                   habit_id=habit.id, day=day, done=True))
                    changed += 1
                    corrected_true += 1
                elif row.done != should:
                    row.done = should
                    changed += 1
                    corrected_true += int(should)
                    corrected_false += int(not should)

                # The stored day score is the quality number; recompute it too
                # so an excused day reads as a full day rather than as half.
                score = svc.prayer_score(statuses, gender, excused)
                if state is None:
                    if score:
                        s.add(PrayerDay(workspace_id=habit.workspace_id, day=day,
                                        excused=excused, score=score))
                elif float(state.score) != score:
                    state.score = score
        s.commit()

    return {"migration": "0004_recompute_prayer_completion",
            "habit_logs_changed": changed,
            "now_complete": corrected_true, "no_longer_complete": corrected_false}


#: Where each previous theme name lands. The five themes were rebuilt as five
#: distinct visual systems rather than five palettes, so the names changed with
#: them. The mapping is by intent, not by hue: someone who picked the restrained
#: dark one still gets a restrained dark one.
THEME_RENAMES = {
    "cobalt": "ocean",       # the old default blue -> the new default blue
    "slate": "midnight",     # restrained and dark -> restrained and dark
    "oxford": "pure",        # formal on paper -> paper
    "blossom": "aurora",     # pink -> the violet-to-rose one
    # Older names that migration 0003 mapped into the set above; anyone who
    # never ran it lands in the right place directly.
    "obsidian": "midnight",
    "emerald": "sage",
    "rose": "aurora",
    "pink": "aurora",
}


def m0005_rename_themes() -> dict:
    """Move accounts onto the rebuilt theme set.

    A row holding an old name is not broken — the app reads any unknown value
    as the default — but the stored value and the Settings screen would
    disagree until the user picked something, so it is rewritten once here.

    `aurora` is deliberately absent from the keys: the name survives into the
    new set, so those rows are already valid and must be left untouched.
    """
    from sqlalchemy import update

    from db import User

    moved: dict[str, int] = {}
    with SessionLocal() as s:
        for old, new in THEME_RENAMES.items():
            count = s.execute(
                update(User).where(User.theme == old).values(theme=new)).rowcount
            if count:
                moved[f"{old}→{new}"] = count
        s.commit()
    return {"migration": "0005_rename_themes", "moved": moved,
            "total": sum(moved.values())}


def m0006_restore_journal_habit() -> dict:
    """Bring the journal back as a non-negotiable habit, and backfill it.

    This deliberately reverses migration `0001`. The reasoning there was that a
    journal is a status rather than a habit, and that counting it inflated the
    denominator. The product decision has changed: writing the day up *is* one
    of the non-negotiables, and it completes only when all five questions are
    answered — so it behaves exactly like the prayer habit, mirroring its module
    instead of being tickable by hand.

    For each workspace this un-archives the old habit if one exists (keeping
    every log it already had), creates it if not, and then recomputes its logs
    from the JournalEntry rows, which are never modified.
    """
    from sqlalchemy import func, select as sql_select

    from db import Habit, JournalEntry, Workspace
    import services as svc

    restored = created = backfilled = 0

    with SessionLocal() as s:
        for ws_id in s.scalars(sql_select(Workspace.id)).all():
            habit = s.scalar(sql_select(Habit).where(
                Habit.workspace_id == ws_id,
                Habit.system_key == svc.SYSTEM_JOURNAL))

            if habit is None:
                # Slot it in after the other non-negotiables rather than at the
                # end, so the three derived habits stay together.
                top = s.scalar(sql_select(func.max(Habit.position)).where(
                    Habit.workspace_id == ws_id)) or 0
                habit = Habit(workspace_id=ws_id, name="Kundalik",
                              category="non_negotiable", position=top + 1,
                              is_protected=True,
                              system_key=svc.SYSTEM_JOURNAL)
                s.add(habit)
                created += 1
            elif habit.archived_at is not None:
                habit.archived_at = None
                # An older build called it "Summary"; the product calls it
                # Kundalik now, and the name of a derived habit is the contract.
                habit.name = "Kundalik"
                habit.category = "non_negotiable"
                habit.is_protected = True
                restored += 1
            s.commit()

            # Backfill from what the user actually wrote.
            for day in s.scalars(sql_select(JournalEntry.day).where(
                    JournalEntry.workspace_id == ws_id)).all():
                if svc.sync_journal_habit(s, ws_id, day):
                    backfilled += 1

    return {"migration": "0006_restore_journal_habit",
            "unarchived": restored, "created": created,
            "days_marked_done": backfilled}


#: The redesign replaced the five themes with five complete visual systems, so
#: the names changed with them. Mapped by intent, not by hue: whoever chose the
#: restrained dark one still lands on a restrained dark one.
THEME_REDESIGN = {
    # The set 0005 produced.
    "ocean": "calm",        # the default blue -> the new default blue
    "pure": "calm",         # paper and charcoal -> the light, minimal one
    "midnight": "titan",    # graphite and steel -> obsidian and steel
    "sage": "muse",         # warm, soft, low contrast -> warm and elegant
    "aurora": "nexus",      # violet gradient -> indigo to cyan
    # Anything that never ran 0005 lands correctly in one step.
    "cobalt": "calm",
    "slate": "titan",
    "oxford": "calm",
    "blossom": "muse",
    "obsidian": "titan",
    "emerald": "muse",
    "rose": "muse",
    "pink": "muse",
}


#: The names that are live today. A rename step must never rewrite one of
#: these, or running the chain twice walks a row in a circle: 0008 renames
#: `calm` to `ocean`, and a second pass of 0007 would rename that `ocean`
#: straight back to `calm`.
#:
#: Skipping them is also the semantically right answer rather than a guard
#: bolted on. `ocean` meant "the default blue" in the 0005 set and means the
#: same thing in this one; `aurora` meant "the gradient one" then and means it
#: now. A row holding either is already where the chain was taking it.
LIVE_THEMES = {"ocean", "midnight", "aurora", "bento", "spatial"}


def m0007_redesign_themes() -> dict:
    """Move every account onto the redesigned theme set.

    A row holding an old name is not broken — the app reads anything unknown as
    the default — but the stored value and the Settings screen would disagree
    until the user picked something, so it is rewritten once here.

    Nobody is moved onto `rage`: it has no predecessor, and assigning a theme
    called "execution mode" to someone who never asked for it is not a
    migration, it is a decision on their behalf.
    """
    from sqlalchemy import update

    from db import User

    moved: dict[str, int] = {}
    with SessionLocal() as s:
        for old, new in THEME_REDESIGN.items():
            if old in LIVE_THEMES:
                continue
            count = s.execute(
                update(User).where(User.theme == old).values(theme=new)).rowcount
            if count:
                moved[f"{old}→{new}"] = count
        s.commit()
    return {"migration": "0007_redesign_themes", "moved": moved,
            "total": sum(moved.values())}


#: The five themes were rebuilt again, this time as five named visual systems
#: rather than five moods. Mapped by what the account already had: whoever
#: chose the restrained dark one stays on a restrained dark one, and the
#: default blue stays the default blue.
THEME_SYSTEMS = {
    # The set 0007 produced.
    "calm": "ocean",       # the default blue -> glass over deep blue
    "titan": "midnight",   # obsidian and steel -> calm dark minimal
    "nexus": "aurora",     # indigo to cyan gradient -> aurora glass
    "muse": "bento",       # the softest, lightest one -> the light one
    "rage": "spatial",     # geometry and speed -> depth and motion
    # Anything that never ran 0005 or 0007 lands correctly in one step.
    "pure": "bento", "sage": "bento", "blossom": "bento",
    "emerald": "bento", "rose": "bento", "pink": "bento",
    "cobalt": "ocean", "oxford": "ocean",
    "slate": "midnight", "obsidian": "midnight",
}


def m0008_named_theme_systems() -> dict:
    """Move every account onto the named theme set.

    A row holding an old name is not broken — the app reads anything unknown
    as the default — but the stored value and the Settings screen would
    disagree until the user picked something, so it is rewritten once here.

    `ocean` and `aurora` are also *old* names from the 0005 set, and they are
    deliberately absent from the mapping: they already mean, in the new set,
    the closest thing to what they meant in the old one, so leaving them
    untouched is the correct migration rather than an oversight.
    """
    from sqlalchemy import update

    from db import User

    moved: dict[str, int] = {}
    with SessionLocal() as s:
        for old, new in THEME_SYSTEMS.items():
            count = s.execute(
                update(User).where(User.theme == old).values(theme=new)).rowcount
            if count:
                moved[f"{old}→{new}"] = count
        s.commit()
    return {"migration": "0008_named_theme_systems", "moved": moved,
            "total": sum(moved.values())}


def m0009_split_ritual_event_type() -> dict:
    """Relabel the shared `ritual` XP events as wake / prayer / journal.

    Waking, praying and journalling all wrote `event_type="ritual"`, and the
    `early_riser` achievement counts wake days by reading that column — so a
    user who prayed and wrote daily earned a thirty-day award in about ten.
    The events themselves were always correct and none are deleted: only the
    label was wrong, and it is recoverable because `event_key` carries the
    habit id (`habit:<id>:<day>`) that says which ritual each row was for.

    Idempotent: rows already carrying a specific type no longer match.
    """
    from sqlalchemy import select as sql_select

    from db import Habit, XPEvent

    key_to_type = {"wakeup": "wake", "prayer": "prayer", "journal": "journal"}
    retyped = {"wake": 0, "prayer": 0, "journal": 0}
    skipped = 0

    with SessionLocal() as s:
        habit_type = {h.id: key_to_type.get(h.system_key or "")
                      for h in s.scalars(sql_select(Habit)).all()}
        rows = s.scalars(sql_select(XPEvent)
                         .where(XPEvent.event_type == "ritual")).all()
        for event in rows:
            parts = (event.event_key or "").split(":")
            if len(parts) < 3 or parts[0] != "habit":
                skipped += 1
                continue
            try:
                habit_id = int(parts[1])
            except ValueError:
                skipped += 1
                continue
            new_type = habit_type.get(habit_id)
            if not new_type:
                # The habit was archived and purged, so which ritual this was
                # can no longer be known. Leaving it as "ritual" is the honest
                # outcome: it counts towards nothing rather than the wrong one.
                skipped += 1
                continue
            event.event_type = new_type
            retyped[new_type] += 1
        s.commit()

    return {"migration": "0009_split_ritual_event_type",
            "retyped": retyped, "total": sum(retyped.values()),
            "left_as_ritual": skipped}


def m0010_daily_report_unique() -> dict:
    """Add the once-a-day report constraint to databases created without it.

    `daily_report_logs` relies on UNIQUE(workspace_id, report_type,
    report_date) as its lock — `claim_report` inserts and treats the resulting
    IntegrityError as "somebody else already has this one". `create_all` only
    ever creates whole tables, so a database whose table predates the
    constraint never got it, and on that database the insert always succeeds:
    every tick claims a fresh row and sends the same report again.

    Duplicate rows are collapsed before the index is built, keeping whichever
    row actually reached `sent`. Idempotent, and safe to run twice.
    """
    from sqlalchemy import inspect, text

    table = "daily_report_logs"
    index_name = "uq_daily_report"
    inspector = inspect(db.engine)
    if not inspector.has_table(table):
        return {"migration": "0010_daily_report_unique", "status": "no table"}

    # The columns matter, not the name. A database carrying an older
    # `uq_daily_report` on (workspace_id, report_type) — no date — looks
    # correct to a check that only reads names, and is catastrophic in
    # practice: the first report a user ever receives occupies their only
    # slot, and every day afterwards `claim_report` is refused and skips them
    # in silence. That is indistinguishable, from the outside, from the
    # feature being switched off.
    wanted = ["workspace_id", "report_type", "report_date"]

    def columns_of(entry: dict) -> list:
        return sorted(entry.get("column_names") or entry.get("columns") or [])

    found = [
        *({"name": c["name"], "cols": columns_of(c)}
          for c in inspector.get_unique_constraints(table)),
        *({"name": i["name"], "cols": columns_of(i)}
          for i in inspector.get_indexes(table) if i.get("unique")),
    ]
    correct = [f for f in found if f["cols"] == sorted(wanted)]
    if correct:
        return {"migration": "0010_daily_report_unique",
                "status": "already present", "constraint": correct[0]["name"]}

    # Anything named like ours but covering the wrong columns has to go, or
    # the new index cannot do its job beside it.
    stale = [f for f in found
             if f["name"] and set(f["cols"]) < set(wanted) and "report" in f["name"]]

    removed = 0
    with db.engine.begin() as conn:
        # Keep the best row per slot: a 'sent' row beats anything else, and
        # ties go to the lowest id. Everything else in that slot is redundant.
        keep = conn.execute(text(f"""
            SELECT MIN(CASE WHEN status = 'sent' THEN id END),
                   MIN(id), workspace_id, report_type, report_date
            FROM {table}
            GROUP BY workspace_id, report_type, report_date
        """)).all()
        for sent_id, any_id, ws, kind, day in keep:
            winner = sent_id or any_id
            result = conn.execute(text(f"""
                DELETE FROM {table}
                WHERE workspace_id = :ws AND report_type = :kind
                  AND report_date = :day AND id <> :winner
            """), {"ws": ws, "kind": kind, "day": day, "winner": winner})
            removed += result.rowcount or 0

        for entry in stale:
            try:
                conn.execute(text(f"DROP INDEX {entry['name']}"))
            except Exception:
                # A table CONSTRAINT rather than a bare index; SQLite cannot
                # drop those in place, and on PostgreSQL this is the spelling.
                try:
                    conn.execute(text(
                        f"ALTER TABLE {table} DROP CONSTRAINT {entry['name']}"))
                except Exception:
                    log.warning("could not drop stale constraint %s — drop it "
                                "by hand before rerunning", entry["name"])

        conn.execute(text(
            f"CREATE UNIQUE INDEX {index_name} ON {table} "
            "(workspace_id, report_type, report_date)"))

    return {"migration": "0010_daily_report_unique", "status": "created",
            "duplicates_removed": removed,
            "stale_constraints_dropped": [e["name"] for e in stale]}


def m0011_seed_team_rituals() -> dict:
    """Give every existing team the ritual habits.

    Since v7 a team ritual is *mirrored*: it holds no ticks of its own and is
    read from each member's personal habit, so a prayer is recorded once and
    shown in every team rather than ticked again in each (#23). New teams
    start empty; this remains for teams that want the shared view, and is
    idempotent — a team that already has them is skipped.
    """
    from sqlalchemy import select as sql_select

    import services as svc
    from db import Team

    seeded, teams = 0, 0
    with SessionLocal() as s:
        for team in s.scalars(sql_select(Team)
                              .where(Team.archived_at.is_(None))).all():
            added = svc.seed_team_rituals(s, team.id, team.owner_id)
            if added:
                teams += 1
                seeded += added
        s.commit()
    return {"migration": "0011_seed_team_rituals",
            "teams_updated": teams, "habits_added": seeded}


def m0012_close_past_days() -> dict:
    """Close every past day into a snapshot, under the v7 formula.

    The day-close job finishes yesterday (and up to a week of stragglers) from
    now on. Days before that are still read live — correct, but recomputed on
    every chart. This finishes them once: each past day that has any activity
    row is recomputed from its own logs and closed, so history stops moving.

    Idempotent: a closed day is never rewritten, so a second run closes only
    what the first did not reach. Non-destructive: nothing but `daily_scores`
    is written.
    """
    from datetime import timedelta

    from sqlalchemy import or_, select as sql_select

    import services as svc
    from db import DailyScore, User

    closed, users = 0, 0
    with SessionLocal() as s:
        for user in s.scalars(sql_select(User).where(User.onboarded.is_(True))).all():
            yesterday = svc.today_local(svc.user_tz(user)) - timedelta(days=1)
            days = s.scalars(sql_select(DailyScore.day).where(
                DailyScore.user_id == user.telegram_id,
                DailyScore.day <= yesterday,
                or_(DailyScore.closed.is_(None), DailyScore.closed.is_(False)))).all()
            if not days:
                continue
            users += 1
            for day in sorted(days):
                try:
                    if svc.close_day(s, user.telegram_id, day) is not None:
                        closed += 1
                except Exception:
                    s.rollback()
                    log.exception("could not close %s for %s", day, user.telegram_id)
    return {"migration": "0012_close_past_days", "users": users, "days_closed": closed}


MIGRATIONS = {
    "0001": m0001_retire_summary_habit,
    "0002": m0002_retire_goals,
    "0003": m0003_retire_themes,
    "0004": m0004_recompute_prayer_completion,
    "0005": m0005_rename_themes,
    "0006": m0006_restore_journal_habit,
    "0007": m0007_redesign_themes,
    "0008": m0008_named_theme_systems,
    "0009": m0009_split_ritual_event_type,
    "0010": m0010_daily_report_unique,
    "0011": m0011_seed_team_rituals,
    "0012": m0012_close_past_days,
}


def run(*names: str) -> list[dict]:
    """Apply the named migrations, or all of them in order."""
    db.init_db()
    chosen = names or tuple(sorted(MIGRATIONS))
    results = []
    for name in chosen:
        fn = MIGRATIONS.get(name)
        if fn is None:
            raise SystemExit(f"unknown migration: {name}")
        result = fn()
        log.info("%s", result)
        results.append(result)
    return results


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    for outcome in run(*sys.argv[1:]):
        print(outcome)
